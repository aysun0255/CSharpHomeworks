﻿using System;

/*
 * 3.Modify the application to print your name.
 */

class PrintMyName
{
    static void Main()
    {
        Console.WriteLine("My name is Aysun");
    }
}

