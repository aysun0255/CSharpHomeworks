﻿using System;

/*
 * Create a console application that calculates and prints the square of the number 12345.
 */

class Square
{
    static void Main()
    {
        Console.WriteLine(Math.Sqrt(12345));
    }
}
