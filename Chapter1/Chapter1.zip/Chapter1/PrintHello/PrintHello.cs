﻿using System;

/*
 * 2.Create, compile and run a “Hello C#” console application.
 */
class PrintHello
{
    static void Main()
    {
        Console.WriteLine("Hello C#!");
    }
}

