﻿using System;

/*
 * 6.Create console application that prints your first and last name.
 */

class FirstAndLastname
{
    static void Main()
    {
        Console.WriteLine("Aysun Sedatov");
    }
}

