﻿using System;

/*
 * 4.Declare an integer variable and assign it with the value 254 in hexadecimal format.
 * Use Windows Calculator to find its hexadecimal representation.
 */

class IntWithHexadecimal
{
    static void Main()
    {
        int myHex = 0xFE;//FE - This is the value 254 in hexadecimal format
        Console.WriteLine(myHex);
    }
}

