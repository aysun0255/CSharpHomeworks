﻿using System;

/*
 * 9.Write a program that prints an isosceles triangle of 9 copyright symbols ©. 
 * Use Windows Character Map to find the Unicode code of the © symbol.
 * Note: the © symbol may be displayed incorrectly.
 */

class Triangle
{
    static void Main()
    {
        Console.WriteLine(@"                                   
                                ©©
                               ©  ©
                              ©    ©
                             ©      ©
                            ©        © 
                           ©          ©
                          ©            ©
                         ©              ©
                        ©                ©
                       ©©©©©©©©©©©©©©©©©©©©    ");
    }
}

