﻿using System;

/*
 * 6.Declare a boolean variable called isFemale and assign an appropriate value corresponding to your gender.
 */ 

class Gender
{
    static void Main()
    {
        bool isFemale = false;
        Console.WriteLine("isFemale:{0}",isFemale);
    }
}

